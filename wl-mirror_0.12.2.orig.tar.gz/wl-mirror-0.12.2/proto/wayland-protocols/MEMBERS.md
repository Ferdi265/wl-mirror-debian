# wayland-protocols members

- EFL/Enlightenment: Mike Blumenkrantz <michael.blumenkrantz@gmail.com> (@zmike)
- GTK/Mutter: Jonas Ådahl <jadahl@gmail.com> (@jadahl),
  Carlos Garnacho <carlosg@gnome.org> (@carlosg)
- KWin: Vlad Zahorodnii <vlad.zahorodnii@kde.org> (@zzag),
  David Edmundson <david@davidedmundson.co.uk> (@davidedmundson)
- Mir: Christopher James Halse Rogers <raof@ubuntu.com> (@RAOF),
  Alan Griffiths <alan.griffiths@canonical.com>
- Qt: Eskil Abrahamsen Blomfeldt <eskil.abrahamsen-blomfeldt@qt.io>
  (@eskilblomfeldt)
- Weston: Pekka Paalanen <pekka.paalanen@collabora.com> (@pq),
  Daniel Stone <daniel@fooishbar.org> (@daniels)
- wlroots/Sway: Simon Ser <contact@emersion.fr> (@emersion),
  Simon Zeni <simon@bl4ckb0ne.ca> (@bl4ckb0ne)
